package com.shop.myshop.controller;

import com.shop.myshop.dto.CustomerDto;
import com.shop.myshop.dto.OrderDto;
import com.shop.myshop.entity.Customer;
import com.shop.myshop.entity.Discount;
import com.shop.myshop.entity.Order;
import com.shop.myshop.entity.Product;
import com.shop.myshop.mapper.CustomerMapper;
import com.shop.myshop.mapper.OrderMapper;
import com.shop.myshop.repository.CustomerRepository;
import com.shop.myshop.repository.DiscountRepository;
import com.shop.myshop.repository.OrderRepository;
import com.shop.myshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.*;

@RestController
public class CustomerController {

    @Autowired
    private CustomerMapper customerMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private DiscountRepository discountRepository;

    //--------------------------------------------------------------------------------------------------
    @PostMapping("customer/create")
    public ResponseEntity<Customer> createCustomer(@Valid  @RequestBody CustomerDto customerDto){
        return new ResponseEntity<>(customerRepository
                .save(customerMapper.customerDtoToCustomerModel(customerDto)),
                HttpStatus.CREATED);
    }

//-----------------------------------------------------------------------------------------------

    @PutMapping("customer/update")
    public ResponseEntity<Customer> updateCustomer(@Valid @RequestBody CustomerDto customerDto){
        Optional<Customer> optionalCustomer=customerRepository.findById(customerDto.getCustomerId());
        if (optionalCustomer.isPresent()){
            return new ResponseEntity<>(customerRepository.save(customerMapper.customerDtoToCustomerModel(customerDto)),HttpStatus.ACCEPTED);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);

    }
//-----------------------------------------------------------------------------------------------

    @DeleteMapping("customer/delete")
    public ResponseEntity<Customer> deleteCustomer(@RequestBody CustomerDto customerDto){
        Optional<Customer> optionalCustomer =customerRepository.findById(customerDto.getCustomerId());
        if (optionalCustomer.isPresent()){
            customerRepository.deleteById(customerDto.getCustomerId());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    //--------------------------------------------------------------------------------------------------
    @PostMapping("order/buy")
    public ResponseEntity<Order> buyproduct(@Valid @RequestBody OrderDto orderDto) {

        Optional<Product> optionalProduct = productRepository.findById(orderDto.getProductId());
        Optional<Discount> optionalDiscount = discountRepository.findById(orderDto.getDiscountCode());

        if (optionalProduct.isPresent()) {
            if (optionalDiscount.isPresent()) {

                Product product1 = optionalProduct.get();
                Discount discount1 = optionalDiscount.get();

                orderDto.setProductId(product1.getProductId());
                orderDto.setProductName(product1.getProductName());
                orderDto.setMobile(orderDto.getMobile());
                orderDto.setEmail(orderDto.getEmail());
                orderDto.setAddress(orderDto.getAddress());
                orderDto.setCouponType(discount1.getCouponType());
                orderDto.setDiscountCode(discount1.getDiscountCode());

                if ("FLAT".equals(orderDto.getCouponType())) {
                    double y = product1.getProductPrice() - discount1.getValue();
                    orderDto.setFinalPrice(y);

                } else if ("PERCENTAGE".equals(orderDto.getCouponType())) {
                    double y = product1.getProductPrice() * discount1.getValue() / 100;
                    orderDto.setFinalPrice(y);
                }

            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }

            return new ResponseEntity<>(orderRepository
                    .save(orderMapper
                            .OrderDtoToOrderModel(orderDto)),HttpStatus.OK);

        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    //--------------------------------------------------------------------------------------------------
    @DeleteMapping("order/cancel")
    public ResponseEntity<Order> cancelProduct(@RequestBody OrderDto orderDto) {

        Optional<Order> optionalOrder = orderRepository.findById(orderDto.getOrderId());
        if (optionalOrder.isPresent()) {
            orderRepository.deleteById(orderDto.getOrderId());
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
}
