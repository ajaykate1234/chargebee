package com.shop.myshop.controller;

import com.shop.myshop.dto.ProductDto;
import com.shop.myshop.entity.Product;
import com.shop.myshop.mapper.ProductMapper;
import com.shop.myshop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class ProductController {
    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/product/insert")
    public ResponseEntity<Product> insertController(@Valid @RequestBody ProductDto productDto){
        return new ResponseEntity<>(productRepository
                .save(productMapper
                        .productDtoToProductModel(productDto)),HttpStatus.CREATED);
    }

    //--------------------------------------------------------------------------------------------------
    @GetMapping("/product/getallproduct")
    public List<Product> showController(){
        return productRepository.findAll();
    }

    //--------------------------------------------------------------------------------------------------
    @PutMapping("/product/update")
    public ResponseEntity<Product> updateProductController(@Valid @RequestBody ProductDto productDto){

        Optional<Product> optionalProduct = productRepository.findById(productDto.getProductId());
        if(optionalProduct.isPresent()) {
            return new ResponseEntity<>(productRepository
                    .save(productMapper
                            .productDtoToProductModel(productDto)), HttpStatus.ACCEPTED);
        }
        {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    //--------------------------------------------------------------------------------------------------

    @DeleteMapping("product/delete")
    public ResponseEntity deleteProductController(@RequestBody ProductDto productDto){
        Optional<Product> productOptional = productRepository.findById(productDto.getProductId());
        if(productOptional.isPresent()){
            productRepository.deleteById(productDto.getProductId());
            return new ResponseEntity<>(HttpStatus.ACCEPTED);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

   }

}
