package com.shop.myshop.controller;

import com.shop.myshop.dto.DiscountDto;
import com.shop.myshop.entity.Discount;
import com.shop.myshop.mapper.DiscountMapper;
import com.shop.myshop.repository.DiscountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class DiscountController {

    @Autowired
    private DiscountDto discountDto;
    @Autowired
    private DiscountMapper discountMapper;
    @Autowired
    private DiscountRepository discountRepository;

    //-------------------------------------------------------------------------------

    @PostMapping("/discount/create")
    public ResponseEntity<Discount> createDiscount(@Valid  @RequestBody DiscountDto discountDto){
        return new ResponseEntity<>(discountRepository.save(discountMapper.DiscountDtoToDiscountModel(discountDto)), HttpStatus.CREATED);
    }

    //-------------------------------------------------------------------------------

    //To Delete Particular Coupon Code
    @DeleteMapping("/discount/delete")
    public ResponseEntity<Discount> deleteDiscount( @RequestBody DiscountDto discountDto){
        Optional<Discount> optionalDiscount=discountRepository.findById(discountDto.getDiscountCode());
        if (optionalDiscount.isPresent()){
            discountRepository.deleteById(discountDto.getDiscountCode());
            return new ResponseEntity<>(HttpStatus.ACCEPTED);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    //--------------------------------------------------------------------------------

    //To get all Discount Coupon Codes
    @GetMapping("/discount/getall")
    public List<Discount> getAllDiscount(){
        return discountRepository.findAll();
    }

    //----------------------------------------------------------------------------------

    //To Update Particular Coupon Code
    @PutMapping("/discount/update")
    public ResponseEntity<Discount> updateDiscount(@Valid @RequestBody DiscountDto discountDto){
        Optional<Discount> optionalDiscount= discountRepository.findById(discountDto.getDiscountCode());
        if (optionalDiscount.isPresent()){
            return new ResponseEntity<>(discountRepository.save(discountMapper.DiscountDtoToDiscountModel(discountDto)),HttpStatus.ACCEPTED);

        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}