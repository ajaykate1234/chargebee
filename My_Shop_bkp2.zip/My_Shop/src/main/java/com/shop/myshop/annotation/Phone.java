package com.shop.myshop.annotation;
import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Constraint(validatedBy = PhoneValicator.class)
public @interface Phone {
    String message() default "Phone size should be 10";

    Class<?>[] group() default {};
    Class<? extends Payload>[] payload() default {};
}